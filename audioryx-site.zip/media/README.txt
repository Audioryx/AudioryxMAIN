Place your audio files (mp3, m4a, etc.) here. The demo expects files named:
- aurora-drift.mp3
- glass-nights.mp3
- neon-tide.mp3
You can also upload tracks using the Upload button in the UI (client-side only).